# engsoccerdata 0.1.5

* Added a `NEWS.md` file to track changes to the package.



